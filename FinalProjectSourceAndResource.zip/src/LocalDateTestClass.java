import java.util.Date;

public class LocalDateTestClass {
    public static void main(String[] args){
//        //Default constructor
//        LocalDate date1=new LocalDate() ;
//       String result= date1.toString();
//        System.out.println(result);

        LocalDate date2=new LocalDate(22,100,2005);
        System.out.println(date2.toString());

//        Date date = new Date(11, 5, 21);
//        Date date22 = new Date(15, 1, 21);
//
//        // tests if date 2 is before date and print
//        boolean before = date22.before(date);
//        System.out.println("Date 2 is before date: " + before);

    }
}
