public class LocalDateInvalid extends Exception {
    public LocalDateInvalid(){
        super();
    }

    public LocalDateInvalid(String statement){
        super(statement);
    }
}
