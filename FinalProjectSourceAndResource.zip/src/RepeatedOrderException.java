public class RepeatedOrderException extends Exception {
    public RepeatedOrderException(){
        super();
    }

    public RepeatedOrderException(String message){
        super(message);
    }
}
