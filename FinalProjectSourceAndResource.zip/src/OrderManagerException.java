public class OrderManagerException extends Exception {
    public OrderManagerException(){
        super();
    }

    public OrderManagerException(String statement){
        super(statement);
    }
}
