public class UserInterfaceException extends Exception {

    public UserInterfaceException(){
        super();
    }

    public UserInterfaceException(String statement){
        super(statement);
    }
}
